import React from "react";
export default function OnboardingSequenceNew() {
  return null;
}
