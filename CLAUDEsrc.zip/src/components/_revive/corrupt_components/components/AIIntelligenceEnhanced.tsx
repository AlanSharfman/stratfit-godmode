export { default } from "./AIIntelligence";
