export type OnboardingSequenceNewProps = {
  onComplete?: () => void;
};

export default function OnboardingSequenceNew(_props: OnboardingSequenceNewProps) {
  return null;
}
